<?php
/**
 * News Resource Collection
 */
namespace Vikhyat\News\Model\ResourceModel\News;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Vikhyat\News\Model\News', 'Vikhyat\News\Model\ResourceModel\News');
    }
}
