<?php
namespace Vikhyat\News\Controller\Index;

use Vikhyat\News\Controller\NewsInterface;

class View extends \Vikhyat\News\Controller\AbstractController\View implements NewsInterface
{

}
